from flask import Flask, request, jsonify, redirect, url_for, render_template, flash, send_from_directory
import pymysql
import pymysql.cursors
import pandas as pd
import spacy
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score
from sklearn.metrics.pairwise import cosine_similarity





# Flask应用初始化
app = Flask(__name__)

# 数据库连接配置
def get_db_connection():
    return pymysql.connect(host='localhost',
                             user='root',
                             password='password',
                             database='userpass',
                             cursorclass=pymysql.cursors.DictCursor)

app.config['SECRET_KEY'] = 'your_secret_key'

# Load NLP model
nlp = spacy.load("en_core_web_sm")


# Load products data
def load_products():
    return pd.read_csv('full.csv')

products_df = load_products()

# Function to extract subcategory using NER and nouns
def extract_subcategory_with_ner_and_nouns(title):
    doc = nlp(title)
    subcategories = []
    for ent in doc.ents:
        if ent.label_ in ["PRODUCT", "ORG"]:
            subcategories.append(ent.text)
    nouns = [token.text for token in doc if token.pos_ == "NOUN" and token.text not in subcategories]
    subcategories.extend(nouns)
    return " ".join(subcategories)

products_df['subcategory'] = products_df['title'].apply(extract_subcategory_with_ner_and_nouns)

# Split dataset and train model
X_train, X_test, y_train, y_test = train_test_split(products_df['title'], products_df['subcategory'], test_size=0.25, random_state=42)
model = make_pipeline(TfidfVectorizer(), MultinomialNB())
model.fit(X_train, y_train)
def safe_float_convert(price):
    try:
        return float(price.strip('[]'))
    except ValueError:
        return None
def recommend_similar_items(new_title, sort_order='ascending', price_range=None):
    tfidf_vectorizer = model.named_steps['tfidfvectorizer']
    tfidf_matrix = tfidf_vectorizer.transform(products_df['title'])
    new_title_vector = tfidf_vectorizer.transform([new_title])
    cosine_similarities = cosine_similarity(new_title_vector, tfidf_matrix).flatten()
    products_df['similarity'] = cosine_similarities
    predicted_category = model.predict([new_title])[0]

    # Filter by subcategory
    filtered_items = products_df[products_df['subcategory'].str.contains(predicted_category, case=False)]

    # Apply price filtering based on the specified range
    if price_range and price_range != 'all':
        if '+' in price_range:  # Handles the "201+" case
            lower_bound = float(price_range[:-1])
            filtered_items = filtered_items[filtered_items['extracted_values'].apply(
                lambda prices: any(safe_float_convert(price) >= lower_bound for price in prices.split(',') if safe_float_convert(price) is not None)
            )]
        else:
            lower_bound, upper_bound = map(float, price_range.split('-'))
            filtered_items = filtered_items[filtered_items['extracted_values'].apply(
                lambda prices: any(lower_bound <= safe_float_convert(price) <= upper_bound for price in prices.split(',') if safe_float_convert(price) is not None)
            )]

    # Sort items based on specified order and similarity
    ascending = sort_order == 'ascending'
    top_items = filtered_items.sort_values(by=['similarity', 'combined_average'], ascending=[False, ascending])

    top_items['title'] = top_items['title'].apply(lambda x: x.title())  # Ensure title is called correctly
    return top_items[['title', 'link']].head(10)


@app.route('/recommend', methods=['POST'])
def recommend():
    new_title = request.form['message']
    sort_order = request.form.get('sort_order', 'ascending')
    price_range = request.form.get('price_range')
    recommended_items = recommend_similar_items(new_title, sort_order, price_range)
    return render_template('recommendation_results.html', recommended_items=recommended_items.to_dict(orient='records'))

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    connection = get_db_connection()
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM userpass WHERE username = %s AND password = %s", (username, password))
        user = cursor.fetchone()
        print (user)
        if user:
            return render_template('index.html', username=username)
        else:
            error = 'Invalid username or password. Please try again.'
            return render_template('login.html', error=error)

    connection.close()

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        connection = get_db_connection()
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM userpass WHERE username = %s", (username,))
            if cursor.fetchone():
                error = 'Username already exists. Please choose a different one.'
                return render_template('register.html', error=error)
            else:
                cursor.execute("INSERT INTO userpass (username, password) VALUES (%s, %s)", (username, password))
                connection.commit()
                # Redirect to the login page after successful registration
                return redirect(url_for('home')) # Assuming your login route is named 'home'
        connection.close()
    else:
        return render_template('register.html')





if __name__ == '__main__':
    # app.run(debug=True,host='192.168.0.1:5000' )
    app.run(host='0.0.0.0',port=5001)



