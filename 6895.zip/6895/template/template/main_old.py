from flask import Flask, request, jsonify, redirect, url_for
import pymysql
import pymysql.cursors
import os 
from flask import send_from_directory     


# Flask应用初始化
app = Flask(__name__)

# 数据库连接配置
connection = pymysql.connect(host='localhost',
                             user='root',
                             password='password',
                             database='userpass',
                             cursorclass=pymysql.cursors.DictCursor)
@app.route('/')
def home():
    return 'Welcome to My Flask App'

@app.route('/home/favicon.ico') 
def favicon(): 
    return send_from_directory(os.path.join(app.root_path, 'static'), 'favicon.ico', mimetype='image/vnd.microsoft.icon')

@app.route('/home/register', methods=['POST'])
def register():
    username = request.form['username']
    password = request.form['password']
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        if cursor.fetchone():
            return jsonify({'message': 'Username already exists!'}), 400
        cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
        connection.commit()
    return jsonify({'message': 'Registered successfully!'}), 201

@app.route('/home/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        user = cursor.fetchone()
        if not user:
            return jsonify({'message': 'User not found!'}), 404
        if user['password'] == password:
            return jsonify({'message': 'Logged in successfully!'})
        else:
            return jsonify({'message': 'Incorrect password!'}), 401

if __name__ == '__main__':
    # app.run(debug=True,host='192.168.0.1:5000' )
    app.run(host='0.0.0.0',port=5001)